from flask import Flask, render_template, request
from transformers import pipeline
from textblob import TextBlob
import pyttsx3
import random

app = Flask(__name__)

# -------------------------------
# LOAD EMOTION MODEL
# -------------------------------
emotion_classifier = pipeline(
    "text-classification",
    model="j-hartmann/emotion-english-distilroberta-base",
    top_k=1
)

# -------------------------------
# EMOTION DETECTION (HYBRID)
# -------------------------------
def detect_emotion(text):
    result = emotion_classifier(text)[0][0]
    
    label = result['label']
    score = result['score']

    mapping = {
        "joy": "happy",
        "anger": "frustrated",
        "sadness": "sad",
        "fear": "concerned",
        "surprise": "surprised",
        "neutral": "neutral"
    }

    emotion = mapping.get(label.lower(), "neutral")

    # Sentiment polarity (improves short text accuracy)
    polarity = TextBlob(text).sentiment.polarity

    if polarity < -0.3:
        return "frustrated", score

    if polarity > 0.3:
        return "happy", score

    # Confidence-based correction
    if score < 0.6:
        return "neutral", score

    if len(text.split()) <= 3:
        return "neutral", score

    return emotion, score


# -------------------------------
# CUSTOMER SERVICE RESPONSE
# -------------------------------
def generate_response(text, emotion):

    responses = {
        "happy": [
            "Thank you for your positive feedback. We're glad to hear that your experience has been good.",
            "We're happy to know that you're satisfied. Please let us know if there's anything else we can assist you with."
        ],

        "frustrated": [
            "I sincerely apologize for the inconvenience caused. I understand your frustration, and I will assist you in resolving this issue.",
            "I'm sorry for your experience. Please allow me to help you address this concern."
        ],

        "sad": [
            "I'm sorry to hear that. Please let me know how I can assist you further.",
            "We understand this may be disappointing. Let us help you with a solution."
        ],

        "concerned": [
            "I understand your concern. Please don't worry, I will assist you and provide the necessary information.",
            "Thank you for bringing this to our attention. Let me help you with the details."
        ],

        "surprised": [
            "I understand this may be unexpected. Let me provide you with more information.",
            "Thank you for highlighting this. I will clarify this for you."
        ],

        "neutral": [
            "Thank you for reaching out. How may I assist you today?",
            "I'm here to help. Please provide more details so I can assist you better."
        ]
    }

    return random.choice(responses.get(emotion, responses["neutral"]))


# -------------------------------
# VOICE MODULATION
# -------------------------------
def speak(text, emotion, intensity):
    engine = pyttsx3.init()

    base_rate = 150
    base_volume = 0.9

    intensity_factor = intensity * 50

    if emotion == "happy":
        engine.setProperty('rate', int(base_rate + intensity_factor))
        engine.setProperty('volume', 1.0)

    elif emotion == "frustrated":
        engine.setProperty('rate', int(base_rate - 30))
        engine.setProperty('volume', 0.7)

    elif emotion == "sad":
        engine.setProperty('rate', int(base_rate - 40))
        engine.setProperty('volume', 0.6)

    elif emotion == "concerned":
        engine.setProperty('rate', int(base_rate - 20))
        engine.setProperty('volume', 0.8)

    elif emotion == "surprised":
        engine.setProperty('rate', int(base_rate + 40))
        engine.setProperty('volume', 1.0)

    else:
        engine.setProperty('rate', base_rate)
        engine.setProperty('volume', base_volume)

    voices = engine.getProperty('voices')
    engine.setProperty('voice', voices[0].id)

    engine.save_to_file(text, "static/output.mp3")
    engine.runAndWait()


# -------------------------------
# ROUTES
# -------------------------------
@app.route("/", methods=["GET", "POST"])
def index():
    response = ""
    emotion = ""

    if request.method == "POST":
        user_input = request.form["text"]

        emotion, intensity = detect_emotion(user_input)
        response = generate_response(user_input, emotion)
        speak(response, emotion, intensity)

    return render_template("index.html", response=response, emotion=emotion)


# -------------------------------
# RUN APP
# -------------------------------
if __name__ == "__main__":
    app.run(debug=False)